import io, json, os, re, uuid, zipfile
from pathlib import Path
import requests
from flask import Flask, jsonify, render_template, request, send_file, abort

app = Flask(__name__)
ROOT = Path(__file__).resolve().parent
OUT = (ROOT / "generated_files").resolve()
OUT.mkdir(exist_ok=True)
SYSTEM = """أنت Dotbhai، مطور برمجيات خبير تتحدث بالعربية.
إذا طلب المستخدم إنشاء ملف أو مشروع، أخرج JSON فقط:
{"type":"files","message":"وصف مختصر","files":[{"name":"index.html","content":"محتوى كامل"}]}
اكتب الملفات كاملة وأضف README عند الحاجة. لا تستخدم مسارات في أسماء الملفات.
إذا كان سؤالًا عاديًا، أخرج {"type":"text","message":"الإجابة"}.
لا تدّعِ اختبار الكود إذا لم تختبره. لا تنشئ أدوات لسرقة البيانات أو التخريب.
"""

def clean_name(value):
    name = str(value).replace("\\", "/").split("/")[-1]
    name = re.sub(r"[^a-zA-Z0-9._\- \u0600-\u06ff]", "_", name).strip(" .")
    if not name or name in {".", ".."}: raise ValueError("اسم ملف غير صالح")
    return name[:100]

def save_files(items, message):
    if not isinstance(items, list) or not items or len(items) > 25:
        raise ValueError("قائمة الملفات غير صالحة")
    pid = uuid.uuid4().hex
    folder = (OUT / pid).resolve()
    folder.mkdir(parents=True, exist_ok=False)
    seen, result, buf = set(), [], io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for item in items:
            if not isinstance(item, dict): continue
            name, content = clean_name(item.get("name", "")), item.get("content", "")
            if not isinstance(content, str) or len(content) > 400_000: raise ValueError("محتوى ملف غير صالح")
            if name in seen or name == "project.zip": raise ValueError("أسماء ملفات مكررة أو محجوزة")
            seen.add(name)
            path = (folder / name).resolve()
            if path.parent != folder: raise ValueError("مسار غير صالح")
            path.write_text(content, encoding="utf-8")
            z.writestr(name, content)
            result.append({"name": name, "url": f"/download/{pid}/{name}"})
    (folder / "project.zip").write_bytes(buf.getvalue())
    return jsonify(message=str(message or "تم إنشاء الملفات"), files=result,
                   zip_url=f"/download/{pid}/project.zip")

@app.get("/")
def home(): return render_template("index.html")

@app.get("/health")
def health(): return jsonify(status="ok")

@app.post("/api/ask")
def ask():
    data = request.get_json(silent=True) or {}
    question = str(data.get("question", "")).strip()
    if not question: return jsonify(error="اكتب طلبك أولًا."), 400
    if len(question) > 12000: return jsonify(error="الطلب طويل جدًا."), 413
    if not os.getenv("OPENAI_API_KEY"):
        return jsonify(error="لم تضبط مفتاح API. اختر Ollama المحلي أو أضف OPENAI_API_KEY في إعدادات الخادم."), 503
    try:
        from openai import OpenAI
        client = OpenAI()
        r = client.responses.create(model=os.getenv("OPENAI_MODEL", "gpt-5"),
                                   instructions=SYSTEM, input=question)
        payload = json.loads(r.output_text.strip())
        if payload.get("type") == "text": return jsonify(message=str(payload.get("message", "")), files=[])
        if payload.get("type") != "files": raise ValueError("استجابة غير معروفة")
        return save_files(payload.get("files"), payload.get("message"))
    except Exception:
        app.logger.exception("API request failed")
        return jsonify(error="فشل الطلب. تحقق من المفتاح واسم النموذج وسجل الخادم."), 502



@app.post("/api/openrouter")
def openrouter_ask():
    """Hosted model endpoint; API key stays in server environment."""
    data = request.get_json(silent=True) or {}
    question = str(data.get("question", "")).strip()
    if not question:
        return jsonify(error="اكتب طلبك أولًا."), 400
    if len(question) > 12000:
        return jsonify(error="الطلب طويل جدًا."), 413
    api_key = os.getenv("OPENROUTER_API_KEY", "").strip()
    if not api_key:
        return jsonify(error="أولًا أضف OPENROUTER_API_KEY في إعدادات Environment على الاستضافة."), 503
    prompt = SYSTEM + "\nأخرج JSON صالحًا فقط. لا تضف Markdown خارج JSON.\n\nطلب المستخدم:\n" + question
    try:
        r = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": "Bearer " + api_key,
                "Content-Type": "application/json",
                "HTTP-Referer": os.getenv("SITE_URL", "https://example.com"),
                "X-Title": "Dotbhai AI"
            },
            json={
                "model": "openrouter/free",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.4
            },
            timeout=90
        )
        if r.status_code >= 400:
            app.logger.warning("OpenRouter returned status %s", r.status_code)
            return jsonify(error="خدمة النموذج رفضت الطلب. تحقق من المفتاح وحدود الاستخدام في OpenRouter."), 502
        content = r.json().get("choices", [{}])[0].get("message", {}).get("content", "")
        if isinstance(content, list):
            content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
        content = str(content).strip()
        # Allow models that wrap JSON in a markdown fence.
        content = re.sub(r"^```(?:json)?\\s*|\\s*```$", "", content, flags=re.I)
        payload = json.loads(content)
        if payload.get("type") == "text":
            return jsonify(message=str(payload.get("message", "")), files=[])
        if payload.get("type") != "files":
            return jsonify(error="النموذج لم يُرجع صيغة ملفات مفهومة. جرّب صياغة طلبك بشكل أبسط."), 502
        return save_files(payload.get("files"), payload.get("message"))
    except json.JSONDecodeError:
        return jsonify(error="رد النموذج لم يكن بصيغة صحيحة. أعد المحاولة أو اطلب ملفًا أبسط."), 502
    except requests.RequestException:
        return jsonify(error="تعذر الاتصال بخدمة النموذج. حاول لاحقًا."), 502
    except Exception:
        app.logger.exception("OpenRouter request failed")
        return jsonify(error="حدث خطأ أثناء تجهيز الرد."), 502


@app.post("/api/ollama")
def ollama():
    data = request.get_json(silent=True) or {}
    question = str(data.get("question", "")).strip()
    if not question: return jsonify(error="اكتب طلبك أولًا."), 400
    url = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
    model = os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
    try:
        r = requests.post(url + "/api/chat", json={
            "model": model, "stream": False, "format": "json",
            "messages": [{"role":"system","content":SYSTEM},{"role":"user","content":question}]
        }, timeout=180)
        r.raise_for_status()
        payload = json.loads(r.json()["message"]["content"])
        if payload.get("type") == "text": return jsonify(message=str(payload.get("message", "")), files=[])
        if payload.get("type") != "files": raise ValueError("استجابة غير معروفة")
        return save_files(payload.get("files"), payload.get("message"))
    except Exception:
        app.logger.exception("Ollama request failed")
        return jsonify(error="تعذر الاتصال بالنموذج المحلي. تأكد من تشغيل Ollama وتنزيل النموذج."), 502

@app.post("/api/save-files")
def save_local_files():
    # For a local-browser Ollama response, file creation still passes through this server.
    data = request.get_json(silent=True) or {}
    try: return save_files(data.get("files"), data.get("message"))
    except Exception as e: return jsonify(error=str(e)), 400

@app.get("/download/<pid>/<filename>")
def download(pid, filename):
    if not re.fullmatch(r"[a-f0-9]{32}", pid): abort(404)
    try: filename = clean_name(filename)
    except ValueError: abort(404)
    folder = (OUT / pid).resolve()
    path = (folder / filename).resolve()
    if path.parent != folder or not path.is_file(): abort(404)
    return send_file(path, as_attachment=True, download_name=filename)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
